# Bing Project

This project fetches research papers from PubMed based on a user-specified query and identifies papers with at least one author affiliated with a pharmaceutical or biotech company. The results are returned as a CSV file.